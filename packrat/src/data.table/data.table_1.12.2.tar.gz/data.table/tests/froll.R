require(data.table)
test.data.table(script="froll.Rraw")
